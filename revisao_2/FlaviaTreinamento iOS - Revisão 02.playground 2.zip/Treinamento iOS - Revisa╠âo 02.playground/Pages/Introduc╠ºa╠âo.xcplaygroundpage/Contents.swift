/*:
## Treinamento em desenvolvimento iOS - 2ª Revisão
 
 A revisão será efetuada através de exercícios práticos.
 
  Os seguintes itens da linguagem Swift serão cobertos:
 
- `Funções (Parte 2)`
- `Toamada de Decisões`
- `Instâncias, Métodos e Propriedades`
- `Vetores`
- `Loops`
 
 página 1 of 6  |  [Próximo: Funções](@next)
 */
